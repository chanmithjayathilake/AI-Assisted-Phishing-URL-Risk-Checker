import unittest
from scanner import analyze_url


class TestURLScanner(unittest.TestCase):
    def test_benign_structure_no_flags(self):
        self.assertEqual(analyze_url("https://www.python.org")["risk"], "Low")

    def test_http_ip_with_login_risky(self):
        finding = analyze_url("http://192.0.2.1/login")
        self.assertEqual(finding["risk"], "High")

    def test_userinfo_disguise(self):
        finding = analyze_url("https://trusted.example@attacker.example/login")
        self.assertEqual(finding["risk"], "High")

    def test_plain_domain(self):
        self.assertEqual(analyze_url("example.org")["hostname"], "example.org")

    def test_bare_http_invalid(self):
        with self.assertRaises(ValueError):
            analyze_url("http://")

    def test_unsupported_scheme(self):
        with self.assertRaises(ValueError):
            analyze_url("ftp://example.org")

    def test_not_fetching_urls(self):
        # The implementation uses urlsplit only, no requests/socket operations.
        self.assertEqual(analyze_url("https://example.org/a")["risk"], "Low")


if __name__ == "__main__":
    unittest.main()
