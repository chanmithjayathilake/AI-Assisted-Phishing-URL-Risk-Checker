"""Explainable, offline URL-structure checks for an educational phishing PoC.

No network access is performed. Risk scores are heuristic, not probabilities.
"""

from __future__ import annotations

import ipaddress
from urllib.parse import urlsplit

KEYWORDS = (
    "verify", "login", "password", "reset", "account", "update",
    "confirm", "urgent", "unlock", "prize", "banking",
)
SHORTENERS = {"bit.ly", "tinyurl.com", "t.co", "is.gd", "cutt.ly"}


def analyze_url(raw_url: str) -> dict:
    """Return a risk score and human-readable findings without visiting a URL."""
    value = raw_url.strip()
    if not value or len(value) > 2048:
        raise ValueError("Enter a URL containing 1–2048 characters.")
    if any(char.isspace() for char in value):
        raise ValueError("Remove spaces and line breaks from the URL.")

    # Treat a bare hostname as HTTPS for parsing; don't fetch or upgrade anything.
    parsed_value = value if "://" in value else f"https://{value}"
    try:
        parsed = urlsplit(parsed_value)
        if parsed.scheme not in ("http", "https"):
            raise ValueError("Only HTTP and HTTPS URLs are supported.")
        hostname = (parsed.hostname or "").lower().rstrip(".")
        if not hostname or len(hostname) > 253:
            raise ValueError("Enter a valid hostname or IP address.")
        port = parsed.port  # Can raise ValueError for invalid ports.
    except ValueError as exc:
        raise ValueError(f"Invalid URL: {exc}") from exc

    findings: list[dict] = []

    def add(points: int, reason: str) -> None:
        findings.append({"points": points, "reason": reason})

    if parsed.scheme == "http":
        add(10, "HTTP does not encrypt traffic in transit.")
    if parsed.username is not None or parsed.password is not None:
        add(35, "URL includes user information before @, which can disguise the real host.")
    try:
        ipaddress.ip_address(hostname)
        add(25, "The URL uses an IP address instead of a domain name.")
    except ValueError:
        pass
    if "xn--" in hostname:
        add(15, "The domain uses punycode; visually confusing characters may be involved.")
    if len(hostname) > 45:
        add(10, "The hostname is unusually long.")
    if hostname.count(".") >= 3:
        add(10, "The hostname has several subdomain levels.")
    if port is not None and port not in (80, 443):
        add(10, "The URL uses an uncommon web port.")
    if hostname in SHORTENERS:
        add(15, "The link shortener hides the final destination from this static check.")

    # Look at the host/path only: query strings often contain unrelated text.
    host_and_path = f"{hostname}{parsed.path}".lower()
    matched = [word for word in KEYWORDS if word in host_and_path]
    if matched:
        add(min(len(matched) * 8, 24),
            "Contains attention- or credential-related terms: " + ", ".join(matched) + ".")

    score = min(sum(item["points"] for item in findings), 100)
    risk = "High" if score >= 40 else "Medium" if score >= 15 else "Low"
    return {
        "input_url": value,
        "hostname": hostname,
        "score": score,
        "risk": risk,
        "findings": findings,
    }
