"""Simple Streamlit phishing-URL risk checker demo."""

import os

import streamlit as st

from scanner import analyze_url

st.set_page_config(page_title="Phishing URL Risk Checker", page_icon="🔎")
st.title("🔎 AI-Assisted Phishing URL Risk Checker")
st.write("Check URL structure for common phishing indicators without visiting the website.")
st.caption("Educational proof of concept, not a malware scanner or live threat-intelligence check.")

with st.form("url_form"):
    url = st.text_input(
        "Enter a URL", placeholder="https://login-verify.example.net"
    )
    bedrock_ready = bool(os.getenv("BEDROCK_MODEL_ID", "").strip())
    enable_ai = st.checkbox(
        "Add an Amazon Bedrock AI explanation",
        value=False,
        disabled=not bedrock_ready,
    )
    if not bedrock_ready:
        st.caption("Set BEDROCK_MODEL_ID (and AWS credentials) to enable AI explanations.")
    submitted = st.form_submit_button("Analyse URL", type="primary")

if submitted:
    try:
        result = analyze_url(url)
    except ValueError as exc:
        st.error(str(exc))
    else:
        st.subheader("Results")
        st.metric("Heuristic risk score (not a probability)", f"{result['score']} / 100")
        if result["risk"] == "High":
            st.error("High indicators of risk — avoid entering credentials or personal data.")
        elif result["risk"] == "Medium":
            st.warning("Some suspicious indicators — verify the destination independently.")
        else:
            st.info("Few indicators found — this does NOT mean the URL is safe.")
        st.write(f"**Hostname inspected:** `{result['hostname']}`")
        st.write("**Why this score?**")
        if result["findings"]:
            for finding in result["findings"]:
                st.write(f"- +{finding['points']} points: {finding['reason']}")
        else:
            st.write("No URL-structure indicators matched the demo rules.")

        if enable_ai:
            from ai_explainer import explain_with_bedrock
            with st.spinner("Generating an AI explanation..."):
                try:
                    explanation = explain_with_bedrock(result)
                    st.write("**Amazon Bedrock explanation**")
                    st.write(explanation)
                except Exception as exc:
                    st.warning(
                        "AI explanation unavailable. Check AWS credentials, Region, "
                        "model access, and BEDROCK_MODEL_ID. "
                        f"Details: {type(exc).__name__}"
                    )

st.divider()
st.caption(
    "The app never opens the submitted URL. The score is based on URL structure only. "
    "A URL can be malicious even when no suspicious signs are found. "
    "Bedrock is used only for explanations, not as an independently trained detector."
)
