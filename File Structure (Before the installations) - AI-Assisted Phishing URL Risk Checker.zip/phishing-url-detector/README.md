# AI-Assisted Phishing URL Risk Checker

A small interview-ready Python/Streamlit proof of concept. It checks URL **structure** offline using simple heuristics; Amazon Bedrock can optionally explain the findings in plain language. It does not visit the entered URL, fetch websites, query live reputation systems, or train a machine-learning model.

## Architecture

`User URL -> Streamlit UI -> offline Python URL checks -> score and reasons`

Optional: `score/reasons/hostname -> Amazon Bedrock Converse API -> AI explanation`

## Requirements

- Python 3.10+
- `pip install -r requirements.txt`
- AWS account, available Bedrock model, and credentials **only if you enable AI explanations**

## Start (no AWS account needed)

```bash
python -m venv .venv
# macOS/Linux: source .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```

Try the following **synthetic** examples (their scores reflect demo rules, not real reputations):

- `https://www.python.org` — few/no structural flags
- `https://login-verify.example.net` — credential-related keywords
- `http://192.0.2.1/login` — HTTP, IP address, login keyword
- `https://trusted.example@attacker.example/login` — `@` userinfo trick

Run tests with `python -m unittest discover -s tests -v`.

## Optional: connect Amazon Bedrock

1. In AWS Console, select an AWS Region with access to a supported Amazon Bedrock text model. Check available models and required permissions in your account. Set up AWS CLI credentials through IAM Identity Center/SSO or another appropriate identity flow. **Never hardcode or commit credentials.**
2. Make sure your IAM principal has `bedrock:InvokeModel` permission for the selected model/profile as required.
3. Set your environment variables, using the model or inference-profile ID shown by AWS for your Region:

macOS/Linux:
```bash
export AWS_REGION=us-east-1
export BEDROCK_MODEL_ID='YOUR_AVAILABLE_MODEL_OR_INFERENCE_PROFILE_ID'
# If using an AWS CLI profile: export AWS_PROFILE='your-profile-name'
streamlit run app.py
```

Windows PowerShell:
```powershell
$env:AWS_REGION='us-east-1'
$env:BEDROCK_MODEL_ID='YOUR_AVAILABLE_MODEL_OR_INFERENCE_PROFILE_ID'
# If using a configured profile: $env:AWS_PROFILE='your-profile-name'
streamlit run app.py
```

4. Tick **Add an Amazon Bedrock AI explanation** in the app.

**Privacy note:** Only hostname, aggregate score, and detected indicators are sent to Bedrock. The full URL's path/query is not sent, and no URL is visited. Avoid submitting private domains to the AI service unless permitted by your organization.

**Costs:** Bedrock inference is billable; check your model's current regional pricing. Set AWS Budget alerts. The local-only demo makes no AWS API calls.

## How to explain this in an interview

> I built a lightweight phishing URL risk checker in Python and Streamlit. It inspects URL features without visiting sites, assigns an explainable heuristic score, and optionally calls Amazon Bedrock to explain the findings in plain language. I deliberately kept detection separate from the LLM response. This is a proof of concept, not a production-ready classifier.

## Limitations / future improvements

- A low score is **not** proof of safety; a high score can be a false alarm.
- No site is downloaded, DNS lookup performed, redirect followed, or malicious URL visited.
- No model training, domain reputation, certificate validation, or real-time threat feeds.
- Future improvements: evaluate with labelled phishing/benign URL datasets; measure false-positive and false-negative rates; optionally integrate a trusted reputation API; support reporting and alerting.
